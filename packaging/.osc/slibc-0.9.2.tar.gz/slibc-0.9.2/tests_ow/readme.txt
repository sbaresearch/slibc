This directory contains testcases from the Openwatcom compiler.

The following files were copied and slighly modified to run:
OW19/bld/clib/streamio/c/safeio.c
OW19/bld/clib/streamio/c/safefmt.c
OW19/bld/clib/streamio/c/safewfmt.c
OW19/bld/clib/string/c/safestr.c
OW19/bld/clib/string/c/safwstr.c
OW19/bld/clib/time/c/safetime.c
OW19/bld/clib/time/c/safwtime.c
OW19/bld/clib/file/c/safefile.c
OW19/bld/clib/mbyte/c/safembyt.c
