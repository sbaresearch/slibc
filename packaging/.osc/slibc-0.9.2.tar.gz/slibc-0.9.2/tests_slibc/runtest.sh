#!/bin/bash
export LD_LIBRARY_PATH=../src/:$LD_LIBRARY_PATH
./test_slibc